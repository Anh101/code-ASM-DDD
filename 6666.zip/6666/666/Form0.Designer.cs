﻿namespace ClothesBadmintonManagent
{
    partial class Form0
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form0));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtB_UserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtB_Password = new System.Windows.Forms.TextBox();
            this.txtB_CustomerName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rad_female = new System.Windows.Forms.RadioButton();
            this.rad_male = new System.Windows.Forms.RadioButton();
            this.dtp_BirthofDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtB_Phone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtB_email = new System.Windows.Forms.TextBox();
            this.btn_accept = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(365, 211);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "UserName:";
            // 
            // txtB_UserName
            // 
            this.txtB_UserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_UserName.Location = new System.Drawing.Point(226, 264);
            this.txtB_UserName.Multiline = true;
            this.txtB_UserName.Name = "txtB_UserName";
            this.txtB_UserName.Size = new System.Drawing.Size(154, 22);
            this.txtB_UserName.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Password:";
            // 
            // txtB_Password
            // 
            this.txtB_Password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_Password.Location = new System.Drawing.Point(226, 325);
            this.txtB_Password.Multiline = true;
            this.txtB_Password.Name = "txtB_Password";
            this.txtB_Password.PasswordChar = '*';
            this.txtB_Password.Size = new System.Drawing.Size(154, 22);
            this.txtB_Password.TabIndex = 11;
            // 
            // txtB_CustomerName
            // 
            this.txtB_CustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_CustomerName.Location = new System.Drawing.Point(226, 383);
            this.txtB_CustomerName.Multiline = true;
            this.txtB_CustomerName.Name = "txtB_CustomerName";
            this.txtB_CustomerName.Size = new System.Drawing.Size(154, 22);
            this.txtB_CustomerName.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 383);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "NameCustomer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 436);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Gender:";
            // 
            // rad_female
            // 
            this.rad_female.AutoSize = true;
            this.rad_female.Location = new System.Drawing.Point(207, 436);
            this.rad_female.Name = "rad_female";
            this.rad_female.Size = new System.Drawing.Size(81, 20);
            this.rad_female.TabIndex = 13;
            this.rad_female.TabStop = true;
            this.rad_female.Text = "FEMALE";
            this.rad_female.UseVisualStyleBackColor = true;
            // 
            // rad_male
            // 
            this.rad_male.AutoSize = true;
            this.rad_male.Location = new System.Drawing.Point(326, 436);
            this.rad_male.Name = "rad_male";
            this.rad_male.Size = new System.Drawing.Size(64, 20);
            this.rad_male.TabIndex = 14;
            this.rad_male.TabStop = true;
            this.rad_male.Text = "MALE";
            this.rad_male.UseVisualStyleBackColor = true;
            // 
            // dtp_BirthofDate
            // 
            this.dtp_BirthofDate.Location = new System.Drawing.Point(199, 487);
            this.dtp_BirthofDate.Name = "dtp_BirthofDate";
            this.dtp_BirthofDate.Size = new System.Drawing.Size(191, 22);
            this.dtp_BirthofDate.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(46, 487);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "DateOfBirth:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(63, 537);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Phone:";
            // 
            // txtB_Phone
            // 
            this.txtB_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_Phone.Location = new System.Drawing.Point(226, 537);
            this.txtB_Phone.Multiline = true;
            this.txtB_Phone.Name = "txtB_Phone";
            this.txtB_Phone.Size = new System.Drawing.Size(154, 22);
            this.txtB_Phone.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(63, 595);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 21;
            this.label7.Text = "Email:";
            // 
            // txtB_email
            // 
            this.txtB_email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_email.Location = new System.Drawing.Point(226, 593);
            this.txtB_email.Multiline = true;
            this.txtB_email.Name = "txtB_email";
            this.txtB_email.Size = new System.Drawing.Size(154, 22);
            this.txtB_email.TabIndex = 17;
            // 
            // btn_accept
            // 
            this.btn_accept.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_accept.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_accept.Location = new System.Drawing.Point(158, 627);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(87, 28);
            this.btn_accept.TabIndex = 18;
            this.btn_accept.Text = "Accept";
            this.btn_accept.UseVisualStyleBackColor = false;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // Form0
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(424, 667);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.txtB_email);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtB_Phone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtp_BirthofDate);
            this.Controls.Add(this.rad_male);
            this.Controls.Add(this.rad_female);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtB_CustomerName);
            this.Controls.Add(this.txtB_Password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtB_UserName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form0";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtB_UserName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtB_Password;
        private System.Windows.Forms.TextBox txtB_CustomerName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rad_female;
        private System.Windows.Forms.RadioButton rad_male;
        private System.Windows.Forms.DateTimePicker dtp_BirthofDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtB_Phone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtB_email;
        private System.Windows.Forms.Button btn_accept;
    }
}