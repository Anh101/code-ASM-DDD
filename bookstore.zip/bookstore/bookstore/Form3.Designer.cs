﻿namespace ClothesBadmintonManagent
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtB_dateCustomer = new System.Windows.Forms.TextBox();
            this.btn_exitCustomer = new System.Windows.Forms.Button();
            this.btn_deleCustomer = new System.Windows.Forms.Button();
            this.btn_updateCustomer = new System.Windows.Forms.Button();
            this.btn_addCustomer = new System.Windows.Forms.Button();
            this.txtB_emailCustomer = new System.Windows.Forms.TextBox();
            this.txtB_phoneCustomer = new System.Windows.Forms.TextBox();
            this.rad_fema = new System.Windows.Forms.RadioButton();
            this.rad_male = new System.Windows.Forms.RadioButton();
            this.txtB_nameCustomer = new System.Windows.Forms.TextBox();
            this.txtB_idCustomer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grView_hienthi = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grView_hienthi)).BeginInit();
            this.SuspendLayout();
            // 
            // txtB_dateCustomer
            // 
            this.txtB_dateCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_dateCustomer.Location = new System.Drawing.Point(495, 76);
            this.txtB_dateCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtB_dateCustomer.Name = "txtB_dateCustomer";
            this.txtB_dateCustomer.Size = new System.Drawing.Size(157, 20);
            this.txtB_dateCustomer.TabIndex = 53;
            // 
            // btn_exitCustomer
            // 
            this.btn_exitCustomer.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_exitCustomer.Location = new System.Drawing.Point(546, 240);
            this.btn_exitCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.btn_exitCustomer.Name = "btn_exitCustomer";
            this.btn_exitCustomer.Size = new System.Drawing.Size(68, 28);
            this.btn_exitCustomer.TabIndex = 60;
            this.btn_exitCustomer.Text = "EXIT";
            this.btn_exitCustomer.UseVisualStyleBackColor = false;
            // 
            // btn_deleCustomer
            // 
            this.btn_deleCustomer.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_deleCustomer.Location = new System.Drawing.Point(546, 208);
            this.btn_deleCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.btn_deleCustomer.Name = "btn_deleCustomer";
            this.btn_deleCustomer.Size = new System.Drawing.Size(68, 28);
            this.btn_deleCustomer.TabIndex = 59;
            this.btn_deleCustomer.Text = "DELETE";
            this.btn_deleCustomer.UseVisualStyleBackColor = false;
            // 
            // btn_updateCustomer
            // 
            this.btn_updateCustomer.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_updateCustomer.Location = new System.Drawing.Point(450, 240);
            this.btn_updateCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.btn_updateCustomer.Name = "btn_updateCustomer";
            this.btn_updateCustomer.Size = new System.Drawing.Size(68, 28);
            this.btn_updateCustomer.TabIndex = 58;
            this.btn_updateCustomer.Text = "UPDATE";
            this.btn_updateCustomer.UseVisualStyleBackColor = false;
            // 
            // btn_addCustomer
            // 
            this.btn_addCustomer.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_addCustomer.Location = new System.Drawing.Point(450, 208);
            this.btn_addCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addCustomer.Name = "btn_addCustomer";
            this.btn_addCustomer.Size = new System.Drawing.Size(68, 28);
            this.btn_addCustomer.TabIndex = 57;
            this.btn_addCustomer.Text = "ADD";
            this.btn_addCustomer.UseVisualStyleBackColor = false;
            // 
            // txtB_emailCustomer
            // 
            this.txtB_emailCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_emailCustomer.Location = new System.Drawing.Point(495, 177);
            this.txtB_emailCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtB_emailCustomer.Name = "txtB_emailCustomer";
            this.txtB_emailCustomer.Size = new System.Drawing.Size(157, 20);
            this.txtB_emailCustomer.TabIndex = 56;
            // 
            // txtB_phoneCustomer
            // 
            this.txtB_phoneCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_phoneCustomer.Location = new System.Drawing.Point(495, 128);
            this.txtB_phoneCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtB_phoneCustomer.Name = "txtB_phoneCustomer";
            this.txtB_phoneCustomer.Size = new System.Drawing.Size(157, 20);
            this.txtB_phoneCustomer.TabIndex = 55;
            // 
            // rad_fema
            // 
            this.rad_fema.AutoSize = true;
            this.rad_fema.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_fema.Location = new System.Drawing.Point(208, 208);
            this.rad_fema.Margin = new System.Windows.Forms.Padding(2);
            this.rad_fema.Name = "rad_fema";
            this.rad_fema.Size = new System.Drawing.Size(73, 17);
            this.rad_fema.TabIndex = 54;
            this.rad_fema.TabStop = true;
            this.rad_fema.Text = "FEMALE";
            this.rad_fema.UseVisualStyleBackColor = true;
            // 
            // rad_male
            // 
            this.rad_male.AutoSize = true;
            this.rad_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_male.Location = new System.Drawing.Point(118, 208);
            this.rad_male.Margin = new System.Windows.Forms.Padding(2);
            this.rad_male.Name = "rad_male";
            this.rad_male.Size = new System.Drawing.Size(58, 17);
            this.rad_male.TabIndex = 52;
            this.rad_male.TabStop = true;
            this.rad_male.Text = "MALE";
            this.rad_male.UseVisualStyleBackColor = true;
            // 
            // txtB_nameCustomer
            // 
            this.txtB_nameCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_nameCustomer.Location = new System.Drawing.Point(159, 141);
            this.txtB_nameCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtB_nameCustomer.Multiline = true;
            this.txtB_nameCustomer.Name = "txtB_nameCustomer";
            this.txtB_nameCustomer.Size = new System.Drawing.Size(122, 26);
            this.txtB_nameCustomer.TabIndex = 51;
            // 
            // txtB_idCustomer
            // 
            this.txtB_idCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtB_idCustomer.Location = new System.Drawing.Point(159, 92);
            this.txtB_idCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.txtB_idCustomer.Name = "txtB_idCustomer";
            this.txtB_idCustomer.Size = new System.Drawing.Size(122, 20);
            this.txtB_idCustomer.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(240, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 26);
            this.label1.TabIndex = 49;
            this.label1.Text = "Get Customer Data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(410, 176);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 17);
            this.label7.TabIndex = 48;
            this.label7.Text = "Email:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(387, 127);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 17);
            this.label6.TabIndex = 47;
            this.label6.Text = "Number Phone:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(387, 75);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 17);
            this.label5.TabIndex = 46;
            this.label5.Text = "Date of Birth:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(38, 207);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 17);
            this.label4.TabIndex = 45;
            this.label4.Text = "Gender:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 150);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 44;
            this.label3.Text = "Name Customer:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 94);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 17);
            this.label2.TabIndex = 43;
            this.label2.Text = "ID Customer:";
            // 
            // grView_hienthi
            // 
            this.grView_hienthi.BackgroundColor = System.Drawing.SystemColors.ButtonShadow;
            this.grView_hienthi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grView_hienthi.Location = new System.Drawing.Point(13, 286);
            this.grView_hienthi.Margin = new System.Windows.Forms.Padding(2);
            this.grView_hienthi.Name = "grView_hienthi";
            this.grView_hienthi.RowHeadersWidth = 51;
            this.grView_hienthi.RowTemplate.Height = 24;
            this.grView_hienthi.Size = new System.Drawing.Size(683, 153);
            this.grView_hienthi.TabIndex = 42;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 450);
            this.Controls.Add(this.txtB_dateCustomer);
            this.Controls.Add(this.btn_exitCustomer);
            this.Controls.Add(this.btn_deleCustomer);
            this.Controls.Add(this.btn_updateCustomer);
            this.Controls.Add(this.btn_addCustomer);
            this.Controls.Add(this.txtB_emailCustomer);
            this.Controls.Add(this.txtB_phoneCustomer);
            this.Controls.Add(this.rad_fema);
            this.Controls.Add(this.rad_male);
            this.Controls.Add(this.txtB_nameCustomer);
            this.Controls.Add(this.txtB_idCustomer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grView_hienthi);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grView_hienthi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtB_dateCustomer;
        private System.Windows.Forms.Button btn_exitCustomer;
        private System.Windows.Forms.Button btn_deleCustomer;
        private System.Windows.Forms.Button btn_updateCustomer;
        private System.Windows.Forms.Button btn_addCustomer;
        private System.Windows.Forms.TextBox txtB_emailCustomer;
        private System.Windows.Forms.TextBox txtB_phoneCustomer;
        private System.Windows.Forms.RadioButton rad_fema;
        private System.Windows.Forms.RadioButton rad_male;
        private System.Windows.Forms.TextBox txtB_nameCustomer;
        private System.Windows.Forms.TextBox txtB_idCustomer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView grView_hienthi;
    }
}