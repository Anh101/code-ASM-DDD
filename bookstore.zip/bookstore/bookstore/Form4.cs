﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClothesBadmintonManagent
{
    public partial class Form4 : Form
    {
        string connectstring = @"Data Source=HoangLong\long;Initial Catalog=Hig;Integrated Security=True;TrustServerCertificate=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adt;
        DataTable dt = new DataTable();
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(connectstring);
            try
            {
                con.Open();
                cmd = new SqlCommand("select * from Employee", con);
                adt = new SqlDataAdapter(cmd);
                adt.Fill(dt);
                grView_hienthi7.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void grView_hienthi7_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btn_addEmp_Click(object sender, EventArgs e)
        {

        }

        private void btn_updateEmp_Click(object sender, EventArgs e)
        {

        }
        private void btn_deleEmp_Click(object sender, EventArgs e)
        {

        }

        private void btn_exitEmp_Click(object sender, EventArgs e)
        {

        }
        // Method to validate email format
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        // Method to validate phone number format (customize as needed)
        private bool IsValidPhoneNumber(string phone)
        {
            return phone.All(char.IsDigit) && phone.Length == 10; // Example validation for a 10-digit number
        }
        private void LoadEmployeeData()
        {
            dt.Clear();
            adt.Fill(dt);
            grView_hienthi7.DataSource = dt;
        }

    }
}
